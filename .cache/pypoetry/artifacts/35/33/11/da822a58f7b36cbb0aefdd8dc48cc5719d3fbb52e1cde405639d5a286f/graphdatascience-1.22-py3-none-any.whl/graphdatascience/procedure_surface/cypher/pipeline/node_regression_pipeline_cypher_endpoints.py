from __future__ import annotations

from typing import Any

from graphdatascience.call_parameters import CallParameters
from graphdatascience.graph.v2.graph_api import GraphV2
from graphdatascience.procedure_surface.api.default_values import ALL_LABELS, ALL_TYPES
from graphdatascience.procedure_surface.api.model.node_regression_model import NodeRegressionModelV2
from graphdatascience.procedure_surface.api.pipeline.node_regression_metric import NodeRegressionMetric
from graphdatascience.procedure_surface.api.pipeline.node_regression_pipeline import NodeRegressionPipeline
from graphdatascience.procedure_surface.api.pipeline.node_regression_pipeline_endpoints import (
    NodeRegressionPipelineEndpoints,
)
from graphdatascience.procedure_surface.api.pipeline.node_regression_pipeline_results import (
    NodeRegressionPipelineInfoResult,
    NodeRegressionPipelineTrainResult,
)
from graphdatascience.procedure_surface.api.pipeline.node_regression_predict_endpoints import (
    NodeRegressionPipelinePredictEndpoints,
)
from graphdatascience.procedure_surface.api.pipeline.parameter_space_config import convert_to_parameter_space_config
from graphdatascience.procedure_surface.api.pipeline.pipeline_catalog_protocol import PipelineCatalogProtocol
from graphdatascience.procedure_surface.cypher.model_api_cypher import ModelApiCypher
from graphdatascience.procedure_surface.cypher.pipeline.node_regression_predict_cypher_endpoints import (
    NodeRegressionPredictCypherEndpoints,
)
from graphdatascience.procedure_surface.cypher.pipeline.pipeline_catalog_cypher_endpoints import (
    PipelineCatalogCypherEndpoints,
)
from graphdatascience.procedure_surface.utils.config_converter import ConfigConverter
from graphdatascience.query_runner.query_runner import QueryRunner


class NodeRegressionPipelineCypherEndpoints(NodeRegressionPipelineEndpoints):
    def __init__(self, query_runner: QueryRunner):
        self._query_runner = query_runner
        self._pipeline_catalog: PipelineCatalogProtocol = PipelineCatalogCypherEndpoints(query_runner)
        self._predict = NodeRegressionPredictCypherEndpoints(query_runner)

    @property
    def predict(self) -> NodeRegressionPipelinePredictEndpoints:
        return self._predict

    def create(self, pipeline_name: str) -> tuple[NodeRegressionPipeline, NodeRegressionPipelineInfoResult]:
        result = self._query_runner.call_procedure(
            endpoint="gds.alpha.pipeline.nodeRegression.create", params=CallParameters(pipeline_name=pipeline_name)
        ).squeeze()
        return (
            NodeRegressionPipeline(pipeline_name, self, self, self._pipeline_catalog),
            NodeRegressionPipelineInfoResult(**result.to_dict()),
        )

    def get(self, pipeline_name: str) -> NodeRegressionPipeline:
        pipeline_info = self._pipeline_catalog.exists(pipeline_name)
        if not pipeline_info:
            raise ValueError(f"No pipeline named '{pipeline_name}' exists")
        if pipeline_info.pipeline_type != "Node regression training pipeline":
            raise ValueError(f"Pipeline '{pipeline_name}' is not a node regression pipeline")
        return NodeRegressionPipeline(
            pipeline_info.pipeline_name,
            self,
            self,
            self._pipeline_catalog,
        )

    def add_node_property(self, pipeline_name: str, task_name: str, **config: Any) -> NodeRegressionPipelineInfoResult:
        result = self._query_runner.call_procedure(
            endpoint="gds.alpha.pipeline.nodeRegression.addNodeProperty",
            params=CallParameters(
                pipeline_name=pipeline_name,
                task_name=task_name,
                config=ConfigConverter.convert_to_gds_config(**config),
            ),
        ).squeeze()
        return NodeRegressionPipelineInfoResult(**result.to_dict())

    def select_features(
        self, pipeline_name: str, feature_properties: str | list[str]
    ) -> NodeRegressionPipelineInfoResult:
        result = self._query_runner.call_procedure(
            endpoint="gds.alpha.pipeline.nodeRegression.selectFeatures",
            params=CallParameters(pipeline_name=pipeline_name, feature_properties=feature_properties),
        ).squeeze()
        return NodeRegressionPipelineInfoResult(**result.to_dict())

    def add_linear_regression(
        self,
        pipeline_name: str,
        *,
        batch_size: int | tuple[int, int] = 100,
        learning_rate: float | tuple[float, float] = 0.001,
        max_epochs: int | tuple[int, int] = 100,
        min_epochs: int | tuple[int, int] = 1,
        patience: int | tuple[int, int] = 1,
        penalty: float | tuple[float, float] = 0.0,
        tolerance: float | tuple[float, float] = 0.001,
    ) -> NodeRegressionPipelineInfoResult:
        config = convert_to_parameter_space_config(
            range_keys={
                "batch_size",
                "learning_rate",
                "max_epochs",
                "min_epochs",
                "patience",
                "penalty",
                "tolerance",
            },
            batch_size=batch_size,
            learning_rate=learning_rate,
            max_epochs=max_epochs,
            min_epochs=min_epochs,
            patience=patience,
            penalty=penalty,
            tolerance=tolerance,
        )
        result = self._query_runner.call_procedure(
            endpoint="gds.alpha.pipeline.nodeRegression.addLinearRegression",
            params=CallParameters(pipeline_name=pipeline_name, config=config),
        ).squeeze()
        return NodeRegressionPipelineInfoResult(**result.to_dict())

    def add_random_forest(
        self,
        pipeline_name: str,
        *,
        max_depth: int | tuple[int, int] = 2147483647,
        max_features_ratio: float | tuple[float, float] | None = None,
        min_leaf_size: int | tuple[int, int] = 1,
        min_split_size: int | tuple[int, int] = 2,
        number_of_decision_trees: int | tuple[int, int] = 100,
        number_of_samples_ratio: float | tuple[float, float] = 1.0,
    ) -> NodeRegressionPipelineInfoResult:
        config = convert_to_parameter_space_config(
            range_keys={
                "max_depth",
                "max_features_ratio",
                "min_leaf_size",
                "min_split_size",
                "number_of_decision_trees",
                "number_of_samples_ratio",
            },
            max_depth=max_depth,
            max_features_ratio=max_features_ratio,
            min_leaf_size=min_leaf_size,
            min_split_size=min_split_size,
            number_of_decision_trees=number_of_decision_trees,
            number_of_samples_ratio=number_of_samples_ratio,
        )
        result = self._query_runner.call_procedure(
            endpoint="gds.alpha.pipeline.nodeRegression.addRandomForest",
            params=CallParameters(pipeline_name=pipeline_name, config=config),
        ).squeeze()
        return NodeRegressionPipelineInfoResult(**result.to_dict())

    def configure_split(
        self, pipeline_name: str, *, test_fraction: float = 0.3, validation_folds: int = 3
    ) -> NodeRegressionPipelineInfoResult:
        result = self._query_runner.call_procedure(
            endpoint="gds.alpha.pipeline.nodeRegression.configureSplit",
            params=CallParameters(
                pipeline_name=pipeline_name,
                config=ConfigConverter.convert_to_gds_config(
                    test_fraction=test_fraction, validation_folds=validation_folds
                ),
            ),
        ).squeeze()
        return NodeRegressionPipelineInfoResult(**result.to_dict())

    def configure_auto_tuning(self, pipeline_name: str, *, max_trials: int = 10) -> NodeRegressionPipelineInfoResult:
        result = self._query_runner.call_procedure(
            endpoint="gds.alpha.pipeline.nodeRegression.configureAutoTuning",
            params=CallParameters(
                pipeline_name=pipeline_name,
                config=ConfigConverter.convert_to_gds_config(max_trials=max_trials),
            ),
        ).squeeze()
        return NodeRegressionPipelineInfoResult(**result.to_dict())

    def train(
        self,
        G: GraphV2,
        pipeline_name: str,
        *,
        metrics: list[str | NodeRegressionMetric],
        model_name: str,
        target_property: str,
        relationship_types: list[str] = ALL_TYPES,
        target_node_labels: list[str] = ALL_LABELS,
        store_model_to_disk: bool = False,
        random_seed: Any | None = None,
        username: str | None = None,
        log_progress: bool = True,
        sudo: bool = False,
        concurrency: int | None = None,
        job_id: str | None = None,
    ) -> tuple[NodeRegressionModelV2, NodeRegressionPipelineTrainResult]:
        gds_config = ConfigConverter.convert_to_gds_config(
            metrics=[metric.value if isinstance(metric, NodeRegressionMetric) else metric for metric in metrics],
            model_name=model_name,
            pipeline=pipeline_name,
            target_property=target_property,
            relationship_types=relationship_types,
            target_node_labels=target_node_labels,
            store_model_to_disk=store_model_to_disk,
            random_seed=random_seed,
            username=username,
            log_progress=log_progress,
            sudo=sudo,
            concurrency=concurrency,
            job_id=job_id,
        )
        params = CallParameters(graph_name=G.name(), config=gds_config)
        params.ensure_job_id_in_config()
        result = self._query_runner.call_procedure(
            endpoint="gds.alpha.pipeline.nodeRegression.train", params=params, logging=True
        ).squeeze()
        return (
            NodeRegressionModelV2(
                name=model_name,
                model_api=ModelApiCypher(self._query_runner),
                predict_endpoints=self._predict,
            ),
            NodeRegressionPipelineTrainResult(**result.to_dict()),
        )
