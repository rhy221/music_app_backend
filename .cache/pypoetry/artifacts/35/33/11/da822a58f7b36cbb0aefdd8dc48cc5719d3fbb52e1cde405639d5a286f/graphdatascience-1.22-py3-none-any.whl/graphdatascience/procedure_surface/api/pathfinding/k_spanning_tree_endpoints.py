from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from graphdatascience.graph.v2.graph_api import GraphV2
from graphdatascience.procedure_surface.api.base_result import BaseResult
from graphdatascience.procedure_surface.api.default_values import ALL_LABELS, ALL_TYPES


class KSpanningTreeWriteResult(BaseResult):
    effective_node_count: int
    write_millis: int
    post_processing_millis: int
    pre_processing_millis: int
    compute_millis: int
    configuration: dict[str, Any]


class KSpanningTreeEndpoints(ABC):
    @abstractmethod
    def write(
        self,
        G: GraphV2,
        k: int,
        write_property: str,
        source_node: int,
        relationship_weight_property: str | None = None,
        objective: str = "minimum",
        relationship_types: list[str] = ALL_TYPES,
        node_labels: list[str] = ALL_LABELS,
        sudo: bool = False,
        log_progress: bool = True,
        username: str | None = None,
        concurrency: int | None = None,
        job_id: str | None = None,
        write_concurrency: int | None = None,
    ) -> KSpanningTreeWriteResult:
        """
        Runs the k-Spanning tree algorithm and writes the result back to the Neo4j database.

        Parameters
        ----------
        G
           Graph object to use
        k
            Number of spanning trees to compute.
        write_property
            Name of the node property to store the results in.
        source_node
            Node id to use as the starting point.
        relationship_weight_property
            Name of the property to be used as weights.
        objective : str, default="minimum"
            The objective function to optimize. Either "minimum" or "maximum".
        relationship_types
            Filter the graph using the given relationship types. Relationships with any of the given types will be included.
        node_labels
            Filter the graph using the given node labels. Nodes with any of the given labels will be included.
        sudo
            Disable the memory guard.
        log_progress
            Display progress logging.
        username
            As an administrator, impersonate a different user for accessing their graphs.
        concurrency
            Number of concurrent threads to use.
        job_id
            Identifier for the computation.
        write_concurrency
            Number of concurrent threads to use for writing.Returns
        -------
        KSpanningTreeWriteResult
            Result containing statistics and timing information.
        """
        ...
