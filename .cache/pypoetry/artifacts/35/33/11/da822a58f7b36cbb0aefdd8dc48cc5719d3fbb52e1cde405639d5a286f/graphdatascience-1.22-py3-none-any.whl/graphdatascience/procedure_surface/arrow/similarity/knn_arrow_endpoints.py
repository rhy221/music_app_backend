from __future__ import annotations

from typing import Any

from pandas import DataFrame

from graphdatascience.arrow_client.authenticated_flight_client import AuthenticatedArrowClient
from graphdatascience.graph.v2.graph_api import GraphV2
from graphdatascience.procedure_surface.api.default_values import ALL_LABELS, ALL_TYPES
from graphdatascience.procedure_surface.api.estimation_result import EstimationResult
from graphdatascience.procedure_surface.api.job_handle import JobHandle
from graphdatascience.procedure_surface.api.similarity.knn_endpoints import KnnEndpoints
from graphdatascience.procedure_surface.api.similarity.knn_filtered_endpoints import KnnFilteredEndpoints
from graphdatascience.procedure_surface.api.similarity.knn_results import (
    KnnMutateResult,
    KnnStatsResult,
    KnnWriteResult,
)
from graphdatascience.procedure_surface.arrow.relationship_endpoints_helper import RelationshipEndpointsHelper
from graphdatascience.procedure_surface.arrow.similarity.knn_filtered_arrow_endpoints import KnnFilteredArrowEndpoints
from graphdatascience.procedure_surface.arrow.stream_result_mapper import rename_similarity_stream_result
from graphdatascience.query_runner.protocol.write_protocols import WriteProtocol


class KnnArrowEndpoints(KnnEndpoints):
    def __init__(
        self,
        arrow_client: AuthenticatedArrowClient,
        write_protocol: WriteProtocol | None = None,
        show_progress: bool = False,
    ):
        self._endpoints_helper = RelationshipEndpointsHelper(
            arrow_client, write_protocol=write_protocol, show_progress=show_progress
        )

    @property
    def filtered(self) -> KnnFilteredEndpoints:
        return KnnFilteredArrowEndpoints(
            self._endpoints_helper._arrow_client,
            self._endpoints_helper._write_protocol,
            self._endpoints_helper._show_progress,
        )

    def compute(
        self,
        G: GraphV2,
        node_properties: str | list[str] | dict[str, str],
        *,
        top_k: int = 10,
        similarity_cutoff: float = 0.0,
        delta_threshold: float = 0.001,
        max_iterations: int = 100,
        sample_rate: float = 0.5,
        perturbation_rate: float = 0.0,
        random_joins: int = 10,
        random_seed: int | None = None,
        initial_sampler: str = "UNIFORM",
        relationship_types: list[str] = ALL_TYPES,
        node_labels: list[str] = ALL_LABELS,
        sudo: bool = False,
        log_progress: bool = True,
        username: str | None = None,
        concurrency: int | None = None,
        job_id: str | None = None,
    ) -> JobHandle:
        config = self._endpoints_helper.create_base_config(
            G,
            nodeProperties=node_properties,
            topK=top_k,
            similarityCutoff=similarity_cutoff,
            deltaThreshold=delta_threshold,
            maxIterations=max_iterations,
            sampleRate=sample_rate,
            perturbationRate=perturbation_rate,
            randomJoins=random_joins,
            randomSeed=random_seed,
            initialSampler=initial_sampler,
            relationshipTypes=relationship_types,
            nodeLabels=node_labels,
            sudo=sudo,
            logProgress=log_progress,
            username=username,
            concurrency=concurrency,
            jobId=job_id,
        )
        return self._endpoints_helper.run_job(G, "v2/similarity.knn", config)

    def mutate(
        self,
        G: GraphV2,
        mutate_relationship_type: str,
        mutate_property: str,
        node_properties: str | list[str] | dict[str, str],
        top_k: int = 10,
        similarity_cutoff: float = 0.0,
        delta_threshold: float = 0.001,
        max_iterations: int = 100,
        sample_rate: float = 0.5,
        perturbation_rate: float = 0.0,
        random_joins: int = 10,
        random_seed: int | None = None,
        initial_sampler: str = "UNIFORM",
        relationship_types: list[str] = ALL_TYPES,
        node_labels: list[str] = ALL_LABELS,
        sudo: bool = False,
        log_progress: bool = True,
        username: str | None = None,
        concurrency: int | None = None,
        job_id: str | None = None,
    ) -> KnnMutateResult:
        config = self._endpoints_helper.create_base_config(
            G,
            nodeProperties=node_properties,
            topK=top_k,
            similarityCutoff=similarity_cutoff,
            deltaThreshold=delta_threshold,
            maxIterations=max_iterations,
            sampleRate=sample_rate,
            perturbationRate=perturbation_rate,
            randomJoins=random_joins,
            randomSeed=random_seed,
            initialSampler=initial_sampler,
            relationshipTypes=relationship_types,
            nodeLabels=node_labels,
            sudo=sudo,
            logProgress=log_progress,
            username=username,
            concurrency=concurrency,
            jobId=job_id,
        )

        result = self._endpoints_helper.run_job_and_mutate(
            "v2/similarity.knn", config, mutate_property, mutate_relationship_type
        )

        return KnnMutateResult(**result)

    def stats(
        self,
        G: GraphV2,
        node_properties: str | list[str] | dict[str, str],
        top_k: int = 10,
        similarity_cutoff: float = 0.0,
        delta_threshold: float = 0.001,
        max_iterations: int = 100,
        sample_rate: float = 0.5,
        perturbation_rate: float = 0.0,
        random_joins: int = 10,
        random_seed: int | None = None,
        initial_sampler: str = "UNIFORM",
        relationship_types: list[str] = ALL_TYPES,
        node_labels: list[str] = ALL_LABELS,
        sudo: bool = False,
        log_progress: bool = True,
        username: str | None = None,
        concurrency: int | None = None,
        job_id: str | None = None,
    ) -> KnnStatsResult:
        config = self._endpoints_helper.create_base_config(
            G,
            nodeProperties=node_properties,
            topK=top_k,
            similarityCutoff=similarity_cutoff,
            deltaThreshold=delta_threshold,
            maxIterations=max_iterations,
            sampleRate=sample_rate,
            perturbationRate=perturbation_rate,
            randomJoins=random_joins,
            randomSeed=random_seed,
            initialSampler=initial_sampler,
            relationshipTypes=relationship_types,
            nodeLabels=node_labels,
            sudo=sudo,
            logProgress=log_progress,
            username=username,
            concurrency=concurrency,
            jobId=job_id,
        )

        result = self._endpoints_helper.run_job_and_get_summary("v2/similarity.knn", config)
        result["similarityPairs"] = result.pop("relationshipsWritten", 0)
        return KnnStatsResult(**result)

    def stream(
        self,
        G: GraphV2,
        node_properties: str | list[str] | dict[str, str],
        top_k: int = 10,
        similarity_cutoff: float = 0.0,
        delta_threshold: float = 0.001,
        max_iterations: int = 100,
        sample_rate: float = 0.5,
        perturbation_rate: float = 0.0,
        random_joins: int = 10,
        random_seed: int | None = None,
        initial_sampler: str = "UNIFORM",
        relationship_types: list[str] = ALL_TYPES,
        node_labels: list[str] = ALL_LABELS,
        sudo: bool = False,
        log_progress: bool = True,
        username: str | None = None,
        concurrency: int | None = None,
        job_id: str | None = None,
    ) -> DataFrame:
        config = self._endpoints_helper.create_base_config(
            G,
            nodeProperties=node_properties,
            topK=top_k,
            similarityCutoff=similarity_cutoff,
            deltaThreshold=delta_threshold,
            maxIterations=max_iterations,
            sampleRate=sample_rate,
            perturbationRate=perturbation_rate,
            randomJoins=random_joins,
            randomSeed=random_seed,
            initialSampler=initial_sampler,
            relationshipTypes=relationship_types,
            nodeLabels=node_labels,
            sudo=sudo,
            logProgress=log_progress,
            username=username,
            concurrency=concurrency,
            jobId=job_id,
        )
        result = self._endpoints_helper.run_job_and_stream("v2/similarity.knn", G, config)
        rename_similarity_stream_result(result)

        return result

    def write(
        self,
        G: GraphV2,
        write_relationship_type: str,
        write_property: str,
        node_properties: str | list[str] | dict[str, str],
        top_k: int = 10,
        similarity_cutoff: float = 0.0,
        delta_threshold: float = 0.001,
        max_iterations: int = 100,
        sample_rate: float = 0.5,
        perturbation_rate: float = 0.0,
        random_joins: int = 10,
        random_seed: int | None = None,
        initial_sampler: str = "UNIFORM",
        relationship_types: list[str] = ALL_TYPES,
        node_labels: list[str] = ALL_LABELS,
        sudo: bool = False,
        log_progress: bool = True,
        username: str | None = None,
        concurrency: int | None = None,
        job_id: str | None = None,
        write_concurrency: int | None = None,
    ) -> KnnWriteResult:
        config = self._endpoints_helper.create_base_config(
            G,
            nodeProperties=node_properties,
            topK=top_k,
            similarityCutoff=similarity_cutoff,
            deltaThreshold=delta_threshold,
            maxIterations=max_iterations,
            sampleRate=sample_rate,
            perturbationRate=perturbation_rate,
            randomJoins=random_joins,
            randomSeed=random_seed,
            initialSampler=initial_sampler,
            relationshipTypes=relationship_types,
            nodeLabels=node_labels,
            sudo=sudo,
            logProgress=log_progress,
            username=username,
            concurrency=concurrency,
            jobId=job_id,
        )

        result = self._endpoints_helper.run_job_and_write(
            "v2/similarity.knn",
            G,
            config,
            relationship_type_overwrite=write_relationship_type,
            property_overwrites=write_property,
            write_concurrency=write_concurrency,
            concurrency=None,
        )

        return KnnWriteResult(**result)

    def estimate(
        self,
        G: GraphV2 | dict[str, Any],
        node_properties: str | list[str] | dict[str, str],
        top_k: int = 10,
        similarity_cutoff: float = 0.0,
        delta_threshold: float = 0.001,
        max_iterations: int = 100,
        sample_rate: float = 0.5,
        perturbation_rate: float = 0.0,
        random_joins: int = 10,
        random_seed: int | None = None,
        initial_sampler: str = "UNIFORM",
        relationship_types: list[str] = ALL_TYPES,
        node_labels: list[str] = ALL_LABELS,
        sudo: bool = False,
        log_progress: bool = True,
        username: str | None = None,
        concurrency: int | None = None,
        job_id: str | None = None,
    ) -> EstimationResult:
        config = self._endpoints_helper.create_estimate_config(
            nodeProperties=node_properties,
            topK=top_k,
            similarityCutoff=similarity_cutoff,
            deltaThreshold=delta_threshold,
            maxIterations=max_iterations,
            sampleRate=sample_rate,
            perturbationRate=perturbation_rate,
            randomJoins=random_joins,
            randomSeed=random_seed,
            initialSampler=initial_sampler,
            relationshipTypes=relationship_types,
            nodeLabels=node_labels,
            sudo=sudo,
            logProgress=log_progress,
            username=username,
            concurrency=concurrency,
            jobId=job_id,
        )

        return self._endpoints_helper.estimate("v2/similarity.knn.estimate", G, config)
